walk(document.body);

function walk(node) 
{
	var child, next;

	switch ( node.nodeType )  
	{
		case 1:  // Element
		case 9:  // Document
		case 11: // Document fragment
			child = node.firstChild;
			while ( child ) 
			{
				next = child.nextSibling;
				walk(child);
				child = next;
			}
			break;

		case 3: // Text node
			handleText(node);
			break;
	}
}

function handleText(textNode) 
{
	var v = textNode.nodeValue;

	v = v.replace(/\bhe\b/g, "person");
	v = v.replace(/\bshe\b/g, "person");
	v = v.replace(/\bher\b/g, "person");
	v = v.replace(/\bhim\b/g, "person");
	v = v.replace(/\bhis\b/g, "person");
	v = v.replace(/\bhers\b/g, "person");
	v = v.replace(/\bhimself\b/g, "person");
	v = v.replace(/\bherself\b/g, "person");


	textNode.nodeValue = v;
}

